package com.example.mydiscs

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc

//@Preview(showBackground = true)
@Composable
fun GetDiscInfo(
    onSaveButton: (Disc) -> Unit,
    modifier: Modifier = Modifier
) {
    var mold by remember { mutableStateOf("") }
    var speedString by remember { mutableStateOf("") }
    val speed = speedString.toIntOrNull() ?: { speedString = "" }
    var glideString by remember { mutableStateOf("") }
    val glide = glideString.toIntOrNull() ?: { glideString = "" }
    var turnString by remember { mutableStateOf("") }
    val turn = turnString.toIntOrNull() ?: { turnString = "" }
    var fadeString  by remember { mutableStateOf("") }
    val fade = fadeString.toIntOrNull() ?: { fadeString = "" }
    var saveButton by remember { mutableStateOf(false) }
    if( !mold.equals("") && !speedString.equals("") && !glideString.equals("") && !turnString.equals("") && fadeString != ""){
        saveButton = true
    }

    Column(
        modifier = modifier
    ){
        TextField(
            value = mold,
            onValueChange = { mold = it },
            singleLine = true,
            label = { Text("Mold:") }
        )
        TextField(
            value = speedString,
            onValueChange = { speedString = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("Speed:") }
        )
        TextField(
            value = glideString,
            onValueChange = { glideString = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("Glide:") }
        )
        TextField(
            value = turnString,
            onValueChange = { turnString = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("Turn:") }
        )
        TextField(
            value = fadeString,
            onValueChange = { fadeString = it },
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            label = { Text("Fade:") }
        )
        Button(
            onClick = { onSaveButton(Disc(mold,
                speed as Int,
                glide as Int,
                turn as Int,
                fade as Int
            ))},
            enabled = saveButton
        ){
            Text("Save")
        }
    }
}
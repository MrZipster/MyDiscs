package com.example.mydiscs

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mydiscs.testdata.TestData
import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc

//@Preview
@Composable
fun PreviewDiscList(){
    DiscList(TestData().container("Bag1"), onAddButtonClick = {})
}
@Composable
fun DiscList(
    container: Container,
    onAddButtonClick: (Container) -> Unit,
    modifier: Modifier = Modifier
) {
    val discList = container.getList()
    Column{
        Row {
            Text(text = container.name)
            Button(
                onClick = { onAddButtonClick(container) }
            ) {
                Text("Add")
            }
        }
        Row{
            Text(
                text = "Mold",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(2f)
            )
            Text(
                text = "Speed",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Glide",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Turn",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Fade",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
        }
        LazyColumn(modifier = modifier) {
            items(discList){ disc ->
                DiscCard(disc = disc)
            }
        }
    }

}

@Composable
fun DiscCard(
    disc: Disc,
    modifier: Modifier = Modifier
) {
    Card(modifier = Modifier.padding(5.dp)) {
        Row(
            modifier = Modifier
                .padding(5.dp)
                .fillMaxSize()
        ) {
            val textModifier = Modifier
                //.absolutePadding(right = 2.dp, left = 2.dp)
                .height(64.dp)
                .weight(1f)
            Text(
                text = disc.mold,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(2f)
            )
            Text(
                text = "" + disc.speed,
                modifier = textModifier
            )
            Text(
                text = "" + disc.glide,
                modifier = textModifier
            )
            Text(
                text = "" + disc.turn,
                modifier = textModifier
            )
            Text(
                text = "" + disc.fade,
                modifier = textModifier
            )
        }
    }
}

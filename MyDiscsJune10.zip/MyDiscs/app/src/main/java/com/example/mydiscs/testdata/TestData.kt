package com.example.mydiscs.testdata

import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc

class TestData() {

    fun container(name: String): Container{
        val bag = Container(name)
        bag.add(Disc("Destroyer", 12, 5, -1, 3))
        bag.add(Disc("Thunderbird", 9, 5, 0, 2))
        bag.add(Disc("FireBird", 9,3,0,4))
        bag.add(Disc("Buzzz", 5,5,-1,1))
        bag.add(Disc("Tempo", 4,4,0,2))
        bag.add(Disc("Glitch", 1,1,0,0))
        bag.add(Disc("TeeBird", 7,5,0,2))
        bag.add(Disc("Roadrunner",9,5,-4,1))
        bag.add(Disc("Leopard",6,5,-2,1))
        bag.add(Disc("Stig",6,5,-2,1))
        bag.add(Disc("Avenger SS",10,5,-3,1))
        bag.add(Disc("Colt",3,4,-1,1))

        return bag
    }
    fun listOfDisc(): List<Container> {
        val list = listOf(
            container("Discraft BX2"),
            container("Garage Shelf"),
            container("Closet Shelf")
        )
        return list
    }
}
package com.example.mydiscs

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
//import androidx.compose.foundation.text2.input.rememberTextFieldState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mydiscs.testdata.TestData
import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc
import com.example.mydiscs.ui.theme.MyDiscsTheme
import androidx.compose.runtime.mutableStateOf
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyDiscsTheme {
                MyDiscsApp()
            }
        }
    }
}

enum class MyDiscsScreen(){
    Containers,
    ListOfDiscs,
    GetNewDisc
}
//@Preview
@Composable
fun MyDiscsApp(
    navController: NavHostController = rememberNavController()
){
    var clickedContainer by remember { mutableStateOf(TestData().container("Unknown Bag")) }
    var containerList by remember { mutableStateOf(TestData().listOfDisc()) }

    Surface(
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        NavHost(
            navController = navController,
            startDestination = MyDiscsScreen.Containers.name,
            modifier = Modifier
        ) {
            composable(route = MyDiscsScreen.Containers.name) {
                ContainerList(
                    containerList = containerList,
                    onContainerClick = {
                        clickedContainer = (it)
                        navController.navigate(MyDiscsScreen.ListOfDiscs.name)
                    }
                )
            }
            composable(route = MyDiscsScreen.ListOfDiscs.name){
                DiscList(
                    container = clickedContainer,
                    onAddButtonClick = {
                        clickedContainer = (it)
                        navController.navigate(MyDiscsScreen.GetNewDisc.name)
                    }
                )
            }
            composable(route = MyDiscsScreen.GetNewDisc.name){
                GetDiscInfo(
                    onSaveButton = {
                        clickedContainer.add(it)
                        navController.popBackStack()
                    }
                )
            }
        }

    }
}





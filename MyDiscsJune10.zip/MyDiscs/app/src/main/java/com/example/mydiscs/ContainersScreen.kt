package com.example.mydiscs

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.mydiscs.ui.theme.Container

@Composable
fun ContainerCard(
    container: Container,
    onButtonClick: (Container) -> Unit,
    modifier: Modifier = Modifier
){
    Button(
        onClick = { onButtonClick(container) },
        modifier = Modifier
            .fillMaxSize()
            .padding(4.dp)
            .height(64.dp)
    ) {
        Text(container.name)
    }
}

@Composable
fun ContainerList(
    containerList: List<Container>,
    onContainerClick: (Container) -> Unit,
    modifier: Modifier = Modifier
){
    LazyColumn (
        modifier = modifier
    ){
        items(containerList) { container ->
            ContainerCard(
                onButtonClick = { onContainerClick(it) },
                container = container,
                modifier = modifier
            )
        }
    }
}
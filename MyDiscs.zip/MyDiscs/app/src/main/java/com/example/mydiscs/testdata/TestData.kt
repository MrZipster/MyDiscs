package com.example.mydiscs.testdata

import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc

class TestData() {
    fun listOfDisc(): Container {
        val bag1 = Container("Bag1")
        bag1.add(Disc("Destroyer", 12, 5, -1, 3))
        bag1.add(Disc("Thunderbird", 9, 5, 0, 2))
        bag1.add(Disc("FireBird", 9,3,0,4))
        bag1.add(Disc("FireBird", 9,3,0,4))
        bag1.add(Disc("FireBird", 9,3,0,4))
        bag1.add(Disc("FireBird", 9,3,0,4))
        bag1.add(Disc("FireBird", 9,3,0,4))

        return bag1
    }
}
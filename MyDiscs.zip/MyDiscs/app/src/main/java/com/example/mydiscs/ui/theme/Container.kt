package com.example.mydiscs.ui.theme

import java.util.LinkedList

class Container internal constructor(// name of bag or shelf
    val name: String
) {
    var discs: LinkedList<Disc> = LinkedList<Disc>()

    fun add(newDisc: Disc) {
        discs.add(newDisc)
    }

    fun remove(newDisc: Disc) {
        discs.remove(newDisc)
    }

    fun getList(): LinkedList<Disc>{
        return discs
    }
}
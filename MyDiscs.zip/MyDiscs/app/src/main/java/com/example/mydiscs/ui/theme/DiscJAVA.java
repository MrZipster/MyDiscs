package com.example.mydiscs.ui.theme;

public class DiscJAVA {
    String mold;
    short speed;
    short glide;
    short turn;
    short fade;

    DiscJAVA(String mold,short speed,short glide,short turn,short fade){

        this.mold = mold;
        this.speed = speed;
        this.glide = glide;
        this.turn = turn;
        this.fade = fade;
    }

    public String toString(){

        return(mold+"|"+speed+"|"+glide+"|"+turn+"|"+fade);
    }
}

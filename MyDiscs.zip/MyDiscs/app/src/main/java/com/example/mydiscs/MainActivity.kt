package com.example.mydiscs

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.absolutePadding
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.calculateStartPadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
//import androidx.compose.foundation.text2.input.rememberTextFieldState
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.mydiscs.testdata.TestData
import com.example.mydiscs.ui.theme.Container
import com.example.mydiscs.ui.theme.Disc
import com.example.mydiscs.ui.theme.MyDiscsTheme
import androidx.compose.runtime.mutableStateOf
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyDiscsTheme {
                Surface (
                    modifier = Modifier
                        .statusBarsPadding(),
                ) {
                    //var bag1 = Container("Bag 1")
                    //GetDiscInfo(bag1)
                    //ContainerCard(TestData().listOfDisc())
                    MyDiscsApp()
                }
            }
        }
    }
}

enum class MyDiscsScreen(){
    Containers,
    ListOfDiscs,
    GetNewDisc
}
//@Preview
@Composable
fun MyDiscsApp(
    navController: NavHostController = rememberNavController()
){
    var clickedContainer: Container = TestData().listOfDisc()

    Surface(
        modifier = Modifier.statusBarsPadding()
    ) {
        NavHost(
            navController = navController,
            startDestination = MyDiscsScreen.Containers.name,
            modifier = Modifier
        ) {
            composable(route = MyDiscsScreen.Containers.name) {
                ContainerCard(
                    container = clickedContainer,
                    onButtonClick = {
                        clickedContainer = (it)
                        navController.navigate(MyDiscsScreen.ListOfDiscs.name)
                    }
                )
            }
            composable(route = MyDiscsScreen.ListOfDiscs.name){
                DiscList(container = clickedContainer)
            }
        }

    }
}

//@Preview(showBackground = true)
@Composable
fun GetDiscInfo(name: Container, modifier: Modifier = Modifier) {
    var mold: String = ""
    var speed: Int
    var glide: Int
    var turn: Int
    var fade: Int
    Column(
        modifier = modifier
    ){
        TextField(
            value = mold,
            onValueChange = { mold = it },
            label = { Text("Mold:") }
        )
        TextField(
            value = mold,
            onValueChange = { mold = it },
            label = { Text("Speed:") }
        )
        TextField(
            value = mold,
            onValueChange = { mold = it },
            label = { Text("Glide:") }
        )
        TextField(
            value = mold,
            onValueChange = { mold = it },
            label = { Text("Turn:") }
        )
        TextField(
            value = mold,
            onValueChange = { mold = it },
            label = { Text("Fade:") }
        )
    }
}

//@Preview
@Composable
fun PreviewDiscList(){
    DiscList(TestData().listOfDisc())
}
@Composable
fun DiscList(container: Container, modifier: Modifier = Modifier){
    val discList = container.getList()
    Column{
        Row{
            Text(
                    text = "Mold",
                    modifier = Modifier
                        .absolutePadding(right = 2.dp, left = 2.dp)
                        .weight(2f)
            )
            Text(
                text = "Speed",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Glide",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Turn",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "Fade",
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
        }
        LazyColumn(modifier = modifier) {
            items(discList){ disc ->
                DiscCard(disc = disc)
            }
        }
    }

}

@Composable
fun DiscCard(
    disc: Disc,
    modifier: Modifier = Modifier
) {
    Card(modifier = Modifier.padding(5.dp)) {
        Row(
            modifier = Modifier
                .padding(5.dp)
                .fillMaxSize()
        ) {
            Text(
                text = disc.mold,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(2f)
            )
            Text(
                text = "" + disc.speed,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "" + disc.glide,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "" + disc.turn,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
            Text(
                text = "" + disc.fade,
                modifier = Modifier
                    .absolutePadding(right = 2.dp, left = 2.dp)
                    .weight(1f)
            )
        }
    }
}

@Composable
fun ContainerCard(
    container: Container,
    onButtonClick: (Container) -> Unit = {}
){
    Button(
        onClick = { onButtonClick(container) }
    ) {
        Text(container.name)
    }
}

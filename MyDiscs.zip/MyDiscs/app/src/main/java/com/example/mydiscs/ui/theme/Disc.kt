package com.example.mydiscs.ui.theme

class Disc internal constructor(
    var mold: String,
    var speed: Int,
    var glide: Int,
    var turn: Int,
    var fade: Int
) {
    override fun toString(): String {
        return ("$mold|$speed|$glide|$turn|$fade")
    }
}
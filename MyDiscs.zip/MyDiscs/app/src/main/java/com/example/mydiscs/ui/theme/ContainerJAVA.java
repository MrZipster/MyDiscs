package com.example.mydiscs.ui.theme;

import java.util.LinkedList;

public class ContainerJAVA {

    String name;// name of bag or shelf
    LinkedList<Disc> discs;

    ContainerJAVA(String name){
        this.name = name;
        discs = new LinkedList<Disc>();
    }

    void add(Disc newDisc){

        discs.add(newDisc);
    }

    void remove(Disc newDisc){

        discs.remove(newDisc);
    }
}
